% Stationary - decline bench
% Walking flat surface - flat bench
% Walking up - bicep curl
% Walking downstairs - military press
% Elevator up - pullup
% Elevator down - dips
% Running - chest fly

% Added Features

% Zero Crossing Rate
y_accel_count = 0;
y_bar_count = 0;

% Segment of accelerometer and barometer data
y_accel_segment = y_accel_mag(i:i+320-1);
y_bar_segment = y_bar_value(i:i+320-1);

% Loop through the window
for i = 1 :length(y_accel_mag(i:i+320-1))
    % For each passing of the zero axis from below or above
    if y_accel_segment(i-1) <= 0 && y_accel_segment(i) > 0
        % Increment counter
        y_accel_count = y_accel_count+1;
    end

    if y_accel_segment(i-1) >= 0 && y_accel_segment(i) < 0
        y_accel_count = y_accel_count+1;
    end
end

% Loop through the window
for i = 1 :length(y_bar_value(i:i+320-1))
    % For each passing of the zero axis from below or above
    if y_bar_segment(i-1) <= 0 && y_bar_segment(i) > 0
        % Increment counter
        y_bar_count = y_bar_count+1;
    end

    if y_bar_segment(i-1) >= 0 && y_bar_segment(i) < 0
        y_bar_count = y_bar_count+1;
    end
end

y_accel_zero_crossing = y_accel_count/length(y_accel_segment);
y_bar_zero_crossing = y_bar_count/length(y_bar_segment);

% Spectral slope
y_accel_mag_spectral_slope = polyfit(1:FFTLen/2, y_accel_mag_magnitude_spectrum,1);
y_bar_value_spectral_slope = polyfit(1:FFTLen/2, y_bar_value_magnitude_spectrum,1);

y_accel_mag_spectral_slope = y_accel_mag_spectral_slope(0);
y_bar_value_spectral_slope = y_bar_value_spectral_slope(0);

% Root Mean Squared
% Magnitude of wave
y_accel_length = length(y_accel_mag(i:i+320-1)); % Window length
y_bar_length = length(y_bar_value(i:i+320-1)); % Window length

% The formula calls for squaring the values in the window, and then
% proceeding to sum them
y_accel_summed = sum( (y_accel_mag(i:i+320-1)).^2);  
y_bar_summed = sum( (y_bar_value(i:i+320-1)).^2);  

% Following the formula, divide by lengh of window and take the sqrt
y_accel_root_mean = sqrt(y_accel_summed/y_accel_length);  
y_bar_root_mean = sqrt(y_bar_summed/y_bar_length); 


% Bandwidth
% The length between each band
y_accel_mag_spectral = fft(y_accel_mag(i:i+320-1),FFTLen);  % FFT of x
y_bar_value_spectral = fft(y_bar_value(i:i+320-1), FFTLen);

y_accel_mag_spectrum = abs(y_accel_mag_spectral(1:FFTLen/2)); % Find magnitude spectrum
y_bar_value_mag_spectrum = abs(y_bar_value_spectral(1:FFTLen/2)); % Find magnitude spectrum

y_accel_magSq = y_accel_mag_spectrum.^2;     % Magnitude squared
y_bar_value_magSq = y_bar_value_mag_spectrum.^2;     % Magnitude squared

for i = 1: FFTLen/2
    % Followng the formula...
    y_accel_ksc = ((i/FFTLen*fs) - y_accel_mag_spectral_centroid)^2; 
    y_bar_value_ksc = ((i/FFTLen*fs) - y_bar_value_spectral_centroid)^2; 

    y_accel_num(i) = y_accel_ksc * y_accel_magSq(i);    
    y_bar_num(i) = y_bar_value_ksc * y_bar_value_magSq(i);
end

y_accel_num = sum(y_accel_num);
y_bar_num = sum(y_bar_num);

y_accel_den = sum(y_accel_magSq);
y_bar_den = sum(y_bar_value_magSq);

y_accel_bandwidth = sqrt(y_accel_num/y_accel_den);
y_bar_bandwidth = sqrt(y_bar_num/y_bar_den);

% Band Energy Ratio

y_accel_mag_spectral = fft(y_accel_mag(i:i+320-1),FFTLen);  % FFT of x
y_bar_value_spectral = fft(y_bar_value(i:i+320-1), FFTLen);

y_accel_mag_spectrum = abs(y_accel_mag_spectral(1:FFTLen/2)); % Find magnitude spectrum
y_bar_value_spectrum = abs(y_bar_value_spectral(1:FFTLen/2)); % Find magnitude spectrum

% Calculate ranges of bands            
b1 = (1: round(FFTLen/2/8));
b2 = (round(FFTLen/2/8)+1 : round(FFTLen/2/4));
b3 = (round(FFTLen/2/4)+1 : round(FFTLen/2/2));
b4 = (round(FFTLen/2/2)+1 : FFTLen/2);

% Energy in each band
y_accel_total = sum(y_accel_mag_spectrum);     % Total energy (all freqs)
y_bar_total = sum(y_bar_value_spectrum);

y_accel_band_1 = sum(y_accel_mag_spectrum(b1))/y_accel_total;  % Energy in band 1
y_accel_band_2 = sum(y_accel_mag_spectrum(b2))/y_accel_total;  % 2
y_accel_band_3 = sum(y_accel_mag_spectrum(b3))/y_accel_total;  % 3
y_accel_band_4 = sum(y_accel_mag_spectrum(b4))/y_accel_total;  % 4

y_bar_band_1 = sum(y_bar_value_spectrum(b1))/y_bar_total;  % Energy in band 1
y_bar_band_2 = sum(y_bar_value_spectrum(b2))/y_bar_total;  % 2
y_bar_band_3 = sum(y_bar_value_spectrum(b3))/y_bar_total;  % 3
y_bar_band_4 = sum(y_bar_value_spectrum(b4))/y_bar_total;  % 4




